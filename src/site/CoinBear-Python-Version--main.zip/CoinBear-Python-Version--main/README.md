# CoinBear

The official repo for the CryptoCurrency CoinBear, ISO: CBR
